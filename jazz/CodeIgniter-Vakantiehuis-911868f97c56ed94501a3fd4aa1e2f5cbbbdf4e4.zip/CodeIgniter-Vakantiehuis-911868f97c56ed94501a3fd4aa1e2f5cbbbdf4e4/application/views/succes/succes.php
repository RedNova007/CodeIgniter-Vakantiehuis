<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <h2>You succesfully registered your vacationhome!</h2>
</body>
</html>