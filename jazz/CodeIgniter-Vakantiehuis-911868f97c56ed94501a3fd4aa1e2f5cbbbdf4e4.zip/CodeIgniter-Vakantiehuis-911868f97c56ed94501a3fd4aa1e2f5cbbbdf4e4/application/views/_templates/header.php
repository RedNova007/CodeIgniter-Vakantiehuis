<div id="header" class="header">
    <!-- navigation -->   
    <div class="logo">
     	logo
    </div>
    <ul class="navigation">
	    	<li>
	            <a class="topmenu" href="<?php echo base_url(); ?>">Home</a></li>
	        <li>
	            <a class="topmenu" href="<?php echo base_url(); ?>users/registration">Register</a></li> 
	        <li>
	            <a class="topmenu" href="<?php echo base_url(); ?>users/login">Login</a></li>
	        <!--<li>
	        	<a class="topmenu" href="<?php echo base_url(); ?>users/account">Account</a></li>-->
    </ul>
</div>